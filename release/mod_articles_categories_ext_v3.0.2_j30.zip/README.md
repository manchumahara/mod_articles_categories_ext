mod_articles_categories_ext
===========================


Supports multiple parent category


Joomla core mod_articles_categories can not show sub category from multiple parent category, this extended version solves this issue.
